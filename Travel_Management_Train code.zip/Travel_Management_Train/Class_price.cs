﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Travel_Management_Train
{
    internal class Class_price
    {
        public double Seat_Non_Ac = 0;
        public double Seat_Ac = 20;
        public double Cabin_Non_Ac = 50;
        public double Cabin_Ac = 70;

    }
}
