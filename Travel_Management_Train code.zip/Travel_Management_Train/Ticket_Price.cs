﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Travel_Management_Train
{
    internal class Ticket_Price
    {
        public double Dhaka = 30;
        public double Rajshahi = 25;
        public double Khulna = 20;
        public double Sylhet = 35;
        public double Chittagong = 45;
        public double Rangpur = 40;

    }
}
